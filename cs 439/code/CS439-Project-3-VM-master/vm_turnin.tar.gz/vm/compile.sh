make
cp -r megansscripts/* build/
tar -zxvf build/create_helpers.tar.gz
