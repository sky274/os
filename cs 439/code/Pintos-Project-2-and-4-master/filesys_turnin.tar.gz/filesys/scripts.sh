cp megansscripts/* build/
