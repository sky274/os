gcc -Wall -O0 -g msh.c util.c jobs.c -o msh
